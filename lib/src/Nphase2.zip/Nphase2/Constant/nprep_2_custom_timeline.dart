import 'package:flutter/material.dart';
import 'package:flutter_timeline/flutter_timeline.dart';
import 'package:flutter_timeline/indicator_position.dart';
import 'package:n_prep/constants/custom_text_style.dart';
import 'package:n_prep/utils/colors.dart';

class Nprep2CustomTimeline extends StatelessWidget {
  final bool isFirst;
  final bool isLast;
  final topic;
  final mcq;
  final status;
  final image;
  final label;
  final noofattemp;
  final  questionnoofattemp;
  final examstatus;
  final Color labelColor;
  final int step;

  const Nprep2CustomTimeline(
      {Key key,
      this.isFirst,
      this.isLast,
      this.topic,
      this.mcq,
      this.status,
      this.image,
      this.noofattemp,
      this. questionnoofattemp,
      this.examstatus,
      this.labelColor,
      this.step,
      this.label});

  @override
  Widget build(BuildContext context) {
    Size size =MediaQuery.of(context).size;
    return Timeline(

      anchor: IndicatorPosition.center,
      separatorBuilder: (_, __) =>
          SizedBox(height: TimelineTheme.of(context).itemGap),
      isLeftAligned: true,
      altOffset: Offset(1, 1),
      indicatorSize: 17,
      events: [
        TimelineEventDisplay(

          forceLineDrawing: true,
          indicator: CircleAvatar(
          backgroundColor: primary,
          child: Text(step.toString(),style: TextStyle(color: white,
              fontWeight: FontWeight.w500,
              fontFamily: 'Poppins-Regular',
              fontSize: 10),
          )),
          child: Stack(
            children: [
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Container(
                  padding: EdgeInsets.all(0),
                  decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.shade300,
                            spreadRadius: 1,
                            blurRadius: 0.5,
                          )
                        ]),

                  child: Row(

                    children: [
                      Padding(

                        padding: EdgeInsets.all(6),
                        child:   Image.network(image,
                          fit: BoxFit.cover,

                          height: MediaQuery.of(context).size.height *0.08,
                          width: MediaQuery.of(context).size.width * 0.18,),
                      ),

                      Padding(
                        padding:  EdgeInsets.only(left: 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            sizebox_height_5,
                            Container(
                              width: size.width-220,

                              // color: Colors.red,
                              // margin: EdgeInsets.only(top: 3),
                              child: Text(
                                "${topic}",
                                maxLines: 2,
                                 overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: 14,

                                    fontFamily: 'Poppins-Regular',
                                    fontWeight: FontWeight.w500,
                                    color: black54),
                              ),
                            ),
                            sizebox_height_5,
                            Container(
                              width: size.width-160,
                              // color: Colors.red,
                              margin: EdgeInsets.only(right: 0,bottom: 2),
                              child:  Text(
                                '${mcq} Video',
                                style: TextStyle(
                                    fontSize: 12,
                                    fontFamily: 'Poppins-Regular',
                                    fontWeight: FontWeight.w500,
                                    color: noofattemp==0?Colors.grey:Colors.green.shade300),
                              ),
                            ),

                          ],
                        ),
                      ),

                    ],
                  ),
                ),
              ),
              Positioned(
                top: 7,
                right: 7,
                child: label.toString()!="1"?Container():
              Container(
                padding: EdgeInsets.only(left: 7,right: 7,top: 3,bottom: 3),
                decoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(5)),
                    border: Border.all(width: 0.5,color: Colors.grey)
                ),
                child:  Text("Pro",
                    style:
                    TextStyle(fontSize: 10,color: Colors.grey.shade600,)),
                // child: Row(
                //   children: [
                //     Icon(Icons.lock,size: 9,),
                //     Text("PRO",
                //         style:
                //         TextStyle(fontSize: 9,color: Colors.grey.shade600,fontWeight: FontWeight.bold)),
                //   ],
                // ),
              ),
              )
            ],
          ),
        )
      ],
    );
  }
}
