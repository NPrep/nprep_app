import 'package:chewie/chewie.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_windowmanager/flutter_windowmanager.dart';
import 'package:get/get.dart';
import 'package:n_prep/Controller/Setting_controller.dart';
import 'package:n_prep/constants/Api_Urls.dart';
import 'package:n_prep/constants/custom_text_style.dart';
import 'package:n_prep/src/Nphase2/Controller/VideoDetailController.dart';
import 'package:n_prep/utils/colors.dart';
import 'package:readmore/readmore.dart';
// import 'package:simple_pip_mode/pip_widget.dart';
// import 'package:simple_pip_mode/simple_pip.dart';
import 'package:video_player/video_player.dart';

class VideoDetailScreen extends StatefulWidget {
  var CatId;


  VideoDetailScreen({
    this.CatId,
  });

  @override
  State<StatefulWidget> createState() {
    return _VideoDetailScreenState();
  }
}

class _VideoDetailScreenState extends State<VideoDetailScreen> with SingleTickerProviderStateMixin {
  TabController tabController;
  // SimplePip pip=SimplePip();
  VideoDetailcontroller videoDetailcontroller =Get.put(VideoDetailcontroller());
  List TabList = [
    {"time": "00:04:45", "text": "One and a half syndrome"},
  ];
  List TabList2 = [
    {"time": "00:04:45", "text": "One and a half syndrome"},
  ];
  List TabList3 = [
    {
      "text": "PRO",
      "text2": "Introduction to Anatomy",
      "text3": "16 Mint Video ",
      "isPro": false,
    },
  ];
  bool tab = true;




  @override
  void initState() {
    super.initState();
    getdata();
    getvideo();


    tabController = TabController(length: 3, vsync: this);
  }
  getdata(){
    videoDetailcontroller.updatecatid(widget.CatId);
    videoDetailcontroller.FetchVideoDetailData();
  }
  getvideo() async {
    await FlutterWindowManager.addFlags(FlutterWindowManager.FLAG_SECURE);
    // _controller.play();
  }



  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        body: GetBuilder<VideoDetailcontroller>(
          builder: (videoDetailcontroller) {
            if(videoDetailcontroller.VideoDetailloader.value){
              return Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [

                  Center(child: CircularProgressIndicator(color: primary,)),
                  SizedBox(height: 5,),
                  Get.find<SettingController>().settingData['data']['general_settings']['quotes'].length ==0?Text(""):
                  Text(Get.find<SettingController>().settingData['data']['general_settings']['quotes'][random.nextInt(Get.find<SettingController>().settingData['data']['general_settings']['quotes'].length)].toString(),textAlign: TextAlign.justify,style: TextStyle(color: primary,),),

                ],
              );
            }
            else {
            return Column(
              children: [
                sizebox_height_30,

                Stack(
                  clipBehavior: Clip.hardEdge,
                  // clipBehavior = clip.hardEdge,
                  children: [
                    videoDetailcontroller.controller.value.isInitialized
                        ? Container(
                    // height: size.height*0.5,
                    padding: EdgeInsets.all(0.0),
              child: AspectRatio(
                  aspectRatio: videoDetailcontroller
                      .controller.value.aspectRatio,
                  child: Chewie(controller: videoDetailcontroller.chewieController)
              ),
            )                        : Center(
                      child: Container(
                        padding: EdgeInsets.all(0.0),
                        height: 200,
                        child: FittedBox(
                          fit: BoxFit.cover,
                          child: Image.network(
                            '${videoDetailcontroller.VideoDetaildata[0]['thumb_image']}',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 20,
                      left: 5,
                      child: GestureDetector(
                        onTap: () {
                          Get.back();
                        },
                        child: Container(
                          height: 35,
                          width: 35,
                          decoration: BoxDecoration(
                              color: Colors.black45,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(50))),
                          child: Icon(
                            Icons.chevron_left,
                            color: white,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      right: 0,
                      top: 20,
                      child: Image.asset(
                        "assets/nprep2_images/main_logo.png",
                        height: 20,
                        width: 50,
                      ),
                    ),
                    // Positioned(
                    //   top: MediaQuery.of(context).size.height * 0.1,
                    //   // left: MediaQuery.of(context).size.height * 0.2,
                    //   right: MediaQuery.of(context).size.height * 0.1,
                    //   child: FloatingActionButton(
                    //     backgroundColor: Colors.grey.withOpacity(0.5),
                    //     onPressed: () {
                    //       setState(() {
                    //         // pause
                    //         if (videoDetailcontroller.controller.value.isPlaying) {
                    //           videoDetailcontroller.fastForward();;
                    //         } else {
                    //           // play
                    //           videoDetailcontroller.controller.play();
                    //         }
                    //       });
                    //     },
                    //     // icon
                    //     child: Icon( Icons.fast_forward,
                    //     ),
                    //   ),
                    // ),
                    // Positioned(
                    //   top: MediaQuery.of(context).size.height * 0.1,
                    //   left: MediaQuery.of(context).size.height * 0.1,
                    //   // right: MediaQuery.of(context).size.height * 0.1,
                    //   child: FloatingActionButton(
                    //     backgroundColor: Colors.grey.withOpacity(0.5),
                    //     onPressed: () {
                    //       setState(() {
                    //         // pause
                    //         if (videoDetailcontroller.controller.value.isPlaying) {
                    //           videoDetailcontroller.rewind();
                    //         } else {
                    //           // play
                    //           videoDetailcontroller.controller.play();
                    //         }
                    //       });
                    //     },
                    //     // icon
                    //     child: Icon( Icons.fast_rewind,
                    //     ),
                    //   ),
                    // ),
                  ],
                ),
                sizebox_height_15,
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    sizebox_width_10,
                    Expanded(
                      flex: 10,
                      child: ReadMoreText( videoDetailcontroller.VideoDetaildata[0]['title'],
                        textAlign: TextAlign.justify,
                        style: TextStyle(
                            color: black54,
                            fontWeight: FontWeight.w500,
                            fontSize: 14),
                        trimLines: 1,
                        trimMode: TrimMode.Line,
                        trimCollapsedText: 'Read More',
                        trimExpandedText: ' || Show Less',
                        moreStyle: TextStyle(
                            color: black54,
                            fontWeight: FontWeight.w500,
                            fontSize: 14),
                        lessStyle: TextStyle(
                            color: black54,
                            fontWeight: FontWeight.w500,
                            fontSize: 14),
                      ),
                    ),
                    Expanded(
                      flex: 5,
                      child: GestureDetector(
                        onTap: () {},
                        child: Image.asset(
                          "assets/nprep2_images/download.png",
                          height: 15,
                          width: 15,
                        ),
                      ),
                    )
                  ],
                ),
                Divider(
                  thickness: 1,
                  height: 30,
                  color: grey,
                  indent: 0,
                  endIndent: 0,
                ),
                TabBar(
                  indicatorColor: primary,
                  indicatorWeight: 3,
                  unselectedLabelColor: grey,
                  labelColor: primary,

                  // dragStartBehavior: DragStartBehavior.start,
                  controller: tabController,
                  tabs: [
                    Tab(
                      child: Text(
                        'Stamps',
                        style: TextStyle(
                          color: primary,
                          fontSize: 15,
                          // fontWeight: FontWeight.bold
                        ),
                      ),
                    ),
                    Tab(
                      child: Text(
                        'Notes',
                        style: TextStyle(
                          color: black54,
                          fontSize: 15,
                          // fontWeight: FontWeight.bold
                        ),
                      ),
                    ),
                    Tab(
                      child: Text(
                        'Blocks',
                        style: TextStyle(
                          color: black54,
                          fontSize: 15,
                          // fontWeight: FontWeight.bold
                        ),
                      ),
                    ),
                  ],
                ),
                Expanded(
                  child: TabBarView(
                    controller: tabController,
                    children: [
                      Column(
                        children: [
                          ListView.builder(
                              itemCount: videoDetailcontroller.VideoDetaildata[0]['video_stamps'].length,
                              scrollDirection: Axis.vertical,
                              shrinkWrap: true,
                              physics: AlwaysScrollableScrollPhysics(),
                              itemBuilder: (BuildContext context, index) {
                                var Tablistdata =  videoDetailcontroller.VideoDetaildata[0]['video_stamps'][index];
                                return Column(
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          width: size.width * 0.10,
                                          child: Image.asset(
                                            "assets/nprep2_images/timer.png",
                                            height: 20,
                                            width: 20,
                                          ),
                                        ),
                                        sizebox_width_5,
                                        Text(
                                          Tablistdata['time'].toString(),
                                          style: TextStyle(
                                              color: black54,
                                              fontWeight: FontWeight.w700,
                                              fontSize: 15),
                                        ),
                                        sizebox_width_10,
                                        Text(
                                          Tablistdata['title'].toString(),
                                          style: TextStyle(
                                              color: black54,
                                              fontWeight: FontWeight.w400,
                                              fontSize: 15),
                                        ),
                                      ],
                                    ),
                                    Divider(
                                      thickness: 1,
                                      height: 20,
                                      color: grey,
                                      indent: 10,
                                      endIndent: 10,
                                    ),
                                  ],
                                );
                              }),
                        ],
                      ),
                      SingleChildScrollView(
                        child: Stack(
                          children: [
                            Positioned(
                                right: 20,
                                child: GestureDetector(
                                  onTap: () {
                                    // Get.to(FullPage());
                                    videoDetailcontroller.chewieController.showControls;
                                    // pip.onPipEntered();
                                  },
                                  child: Image.asset(
                                    "assets/nprep2_images/zoomOut.png",
                                    height: 20,
                                    width: 20,
                                  ),
                                )),
                            Center(
                              child: Column(
                                children: [
                                  Image.asset(
                                    "assets/nprep2_images/main_image1.png",
                                    width: 250,
                                  ),
                                  sizebox_height_10,
                                  Image.asset(
                                    "assets/nprep2_images/main_image2.png",
                                    width: 250,
                                  ),
                                  sizebox_height_20
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ListView.builder(
                      //     itemCount: TabList2.length,
                      //     scrollDirection: Axis.vertical,
                      //     shrinkWrap: true,
                      //     physics: AlwaysScrollableScrollPhysics(),
                      //     itemBuilder: (BuildContext context, index) {
                      //       var Tablistdata = TabList2[index];
                      //       return
                      //     }),
                      ListView.builder(
                          itemCount: videoDetailcontroller.VideoDetaildata[0]['video_relates'].length,
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          physics: AlwaysScrollableScrollPhysics(),
                          itemBuilder: (BuildContext context, index) {
                            var Tablist2data = videoDetailcontroller.VideoDetaildata[0]['video_relates'][index];
                            return Container(
                              margin: EdgeInsets.symmetric(
                                  vertical: 5, horizontal: 5),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 5, vertical: 5),
                              decoration: BoxDecoration(
                                  border: Border.all(color: hintColor),
                                  borderRadius: BorderRadius.circular(8)),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Tablist2data["isPro"] == true
                                          ? Container()
                                          : Container(
                                              height: 15,
                                              width: 30,
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: todayTextColor),
                                                  borderRadius:
                                                      BorderRadius.circular(4)),
                                              child: Center(
                                                child: Text(
                                                  Tablist2data["text"]
                                                      .toString(),
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      color: todayTextColor,
                                                      fontSize: 10),
                                                ),
                                              ),
                                            )
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Image.asset(
                                        "assets/nprep2_images/sub_image.png",
                                        height: 80,
                                        width: 100,
                                      ),
                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            Tablist2data['text2'].toString(),
                                            style: TextStyle(
                                                color: todayTextColor,
                                                fontSize: 16,
                                                fontWeight: FontWeight.w500),
                                          ),
                                          Text(
                                            Tablist2data['text3'].toString(),
                                            style: TextStyle(
                                                color: todayTextColor,
                                                fontSize: 12),
                                          )
                                        ],
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            );
                          }),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                  height: 40,
                  width: 180,
                  decoration: BoxDecoration(
                    color: Color(0xff64C4DA).withOpacity(0.9),
                    // boxShadow: [
                    //   BoxShadow(
                    //     color: Colors.grey.withOpacity(0.5),
                    //     spreadRadius: 5,
                    //     blurRadius: 10,
                    //     offset: Offset(0, 3), // changes position of shadow
                    //   ),
                    // ],
                    borderRadius: BorderRadius.all(
                      Radius.circular(8),
                    ),
                  ),
                  child: Center(
                      child: Text(
                    "MARK COMPLETE ",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: white,
                        fontSize: 16,
                        fontWeight: FontWeight.w500),
                  )),
                ),
              ],
            );
          }
        }
        ),
      ),
    );
  }
}
