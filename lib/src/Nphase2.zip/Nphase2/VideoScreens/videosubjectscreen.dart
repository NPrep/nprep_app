import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:n_prep/Controller/Setting_controller.dart';
import 'package:n_prep/constants/Api_Urls.dart';
import 'package:n_prep/constants/custom_text_style.dart';
import 'package:n_prep/src/Nphase2/Controller/VideoSubjectController.dart';
import 'package:n_prep/src/Nphase2/VideoScreens/video_sub_subjectscreen.dart';
import 'package:n_prep/utils/colors.dart';


class VideoSubjectScreen extends StatefulWidget {
  const VideoSubjectScreen({Key key}) : super(key: key);

  @override
  State<VideoSubjectScreen> createState() => _VideoSubjectScreenState();
}

class _VideoSubjectScreenState extends State<VideoSubjectScreen> {
  Videosubjectcontroller videosubjectcontroller =Get.put(Videosubjectcontroller());
  final List<Map<String, dynamic>> subjects = [
    {
      "image": "assets/nprep2_images/community.png",
      "text": "Community Medicine",
      "text2": "5/15 subcategory",
    },
    {
      "image": "assets/nprep2_images/biochemistry.png",
      "text": "Biochemistry",
      "text2": "5/15 subcategory",
    },
    {
      "image": "assets/nprep2_images/forensic.png",
      "text": "Forensic medicine",
      "text2": "5/15 subcategory",
    },
    {
      "image": "assets/nprep2_images/pathology.png",
      "text": "Pathology",
      "text2": "5/15 subcategory",
    },
    {
      "image": "assets/nprep2_images/pharmacology.png",
      "text": "Pharmacology",
      "text2": "5/15 subcategory",
    },
    {
      "image": "assets/nprep2_images/physiology.png",
      "text": "Physiology",
      "text2": "5/15 subcategory",
    },
    {
      "image": "assets/nprep2_images/medicine.png",
      "text": "Medicine",
      "text2": "5/15 subcategory",
    },
    {
      "image": "assets/nprep2_images/anatomy.png",
      "text": "Anatomy",
      "text2": "5/15 subcategory",
    },
    {
      "image": "assets/nprep2_images/microbiology.png",
      "text": "Microbiology",
      "text2": "5/15 subcategory",
    },
  ];

  List subject = [
    {
      "text": "Saved",
      "text2": "0/50 Videos",
      "image": "assets/nprep2_images/video.png"
    },
    {
      "text": "Sample Videos ",
      "text2": "Explore",
      "image": "assets/nprep2_images/video.png"
    },
    {
      "text": "Youtube",
      "text2": "Explore",
      "image": "assets/nprep2_images/video.png"
    },
  ];

  bool slide = false;

  int current = 0;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    videosubjectcontroller.FetchSubjectData();
  }
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      // appBar: AppBar(
      //   title: Text("Subjects"),
      //   backgroundColor: primary,
      //   centerTitle: true,
      //   elevation: 0,
      //   leading: Icon(Icons.menu,color: white,),
      //   actions: [
      //     Container(width: size.width * 0.1, child: Icon(Icons.search))
      //   ],
      // ),
      // body: SingleChildScrollView(
      //   child: Container(
      //     height: size.height-120,
      //     width: size.width,
      //     child: Column(
      //       mainAxisAlignment: MainAxisAlignment.center,
      //       crossAxisAlignment: CrossAxisAlignment.center,
      //       children: [
      //
      //         Image.asset('assets/nprep2_images/youtube.png',
      //           height: 260,
      //           width: 220,),
      //         Text("Coming Soon",
      //           style: TextStyle(
      //               fontSize: 26,
      //               color: primary,
      //               fontWeight: FontWeight.w600
      //           ),)
      //       ],
      //     ),
      //   ),
      // ),

      body: GetBuilder<Videosubjectcontroller>(
        builder: (videosubjectcontroller) {
          if(videosubjectcontroller.Videosubjectloader.value){
            return Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                Center(child: CircularProgressIndicator(color: primary,)),
                SizedBox(height: 5,),
                Get.find<SettingController>().settingData['data']['general_settings']['quotes'].length ==0?Text(""):
                Text(Get.find<SettingController>().settingData['data']['general_settings']['quotes'][random.nextInt(Get.find<SettingController>().settingData['data']['general_settings']['quotes'].length)].toString(),textAlign: TextAlign.justify,style: TextStyle(color: primary,),),

              ],
            );
          }else{
            return SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.only(top: 5),
                child: Column(
                  children: [
                    // ElevatedButton(onPressed: (){
                    //   Get.to(Youtube());
                    // },
                    //     child: Text("Video page")),
                    videosubjectcontroller.Videosubjectdata[0]['data']['saved_video_count']==null?Container(): Padding(
                      padding: EdgeInsets.all(10),
                      child: Row(
                        children: [
                          Text(
                            "Continue Watching",
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontWeight: FontWeight.w400,
                                color: textColor,
                                fontSize: 14,
                                letterSpacing: 0.5),
                          ),
                          Text(
                            "${""}",
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: primary,
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                                letterSpacing: 0.5),
                          )
                        ],
                      ),
                    ),
                    videosubjectcontroller.Videosubjectdata[0]['data']['saved_video_count']==null?Container():Padding(
                      padding: EdgeInsets.only(left: 10,right: 10),
                      child: Row(
                        children: [
                          Expanded(
                            flex: 1,
                            child: Divider(
                              color:  primary,
                              height: 12,
                              thickness: 2,
                              indent: 0,
                              endIndent: 0,
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Divider(
                              color:  grey,
                              height: 12,
                              thickness: 2,
                              indent: 0,
                              endIndent: 0,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        slide == false ?GestureDetector(
                          onTap: (){
                            slide = true;
                            setState(() {
                            });

                          },
                          child: Row(
                            children: [
                              Container(
                                height: 40,
                                width: 30,
                                decoration: BoxDecoration(
                                  color: primary,
                                  borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(100),
                                    bottomRight: Radius.circular(100),
                                  ),
                                ),
                                child: Icon(Icons.arrow_forward_ios_outlined,color: white,size: 20,),
                              ),
                              Padding(
                                padding: EdgeInsets.all(10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text("SUBJECTS",
                                      style: TextStyle(
                                          fontSize: 17,
                                          fontWeight: FontWeight.w500,
                                          color: textColor
                                      ),),
                                  ],
                                ),
                              )
                            ],
                          ), //open container
                        ) : Container(),
                        slide == false ? Container( height: 90,) : Container(
                          height: 90,
                          width: size.width-20,
                          child: ListView.builder(
                              itemCount: subject.length,
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              // clipBehavior: Clip.none,
                              physics: AlwaysScrollableScrollPhysics(),
                              itemBuilder: (BuildContext context, index) {
                                var subjectlistdata = subject[index];
                                return Card(
                                  child: Padding(
                                    padding:  EdgeInsets.symmetric(horizontal: 15,vertical: 20),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Image.asset(subjectlistdata["image"].toString(),
                                          height: 30,
                                          width: 30,),
                                        sizebox_width_10,
                                        Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(subjectlistdata["text"].toString(),
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.w500,
                                                letterSpacing: 0.5,
                                              ),),
                                            sizebox_height_5,
                                            Text('${subjectlistdata["text2"]=="0/50 Videos"? "${
                                                      videosubjectcontroller
                                                                  .Videosubjectdata[
                                                              0]['data'][
                                                          'saved_video_count']
                                                    }/${
                                                videosubjectcontroller
                                                    .Videosubjectdata[
                                                0]['data']['saved_video_limit']
                                            } Videos" :subjectlistdata["text2"]}',
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(
                                                  fontSize: 11,
                                                  color: textColor,
                                                  letterSpacing: 0.5
                                              ),)
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                );
                              }),
                        ),
                        slide == true ?
                        GestureDetector(
                          onTap: (){
                            slide = false;
                            setState(() {
                            });
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                // margin: EdgeInsets.symmetric(horizontal: 10,vertical:0),
                                height: 40,
                                width: 20,
                                decoration: BoxDecoration(
                                  color: primary,
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(100),
                                    bottomLeft: Radius.circular(100),
                                  ),
                                ),
                                child: Icon(Icons.arrow_back_ios_new,color: white,size: 20,),
                              ),
                            ],
                          ),
                        ):Container(),
                      ],
                    ),


                    slide == true ?  Padding(
                      padding: EdgeInsets.all(10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text("SUBJECTS",
                            style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w500,
                                color: textColor
                            ),),
                        ],
                      ),
                    ):Container(),


                    GridView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount:  videosubjectcontroller.Videosubjectdata[0]['data']['categories'].length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          mainAxisSpacing: 6,
                          mainAxisExtent: 80,
                        ),
                        itemBuilder: (_, index) {
                          var subjectsData = videosubjectcontroller.Videosubjectdata[0]['data']['categories'][index];
                          return Container(
                            margin: EdgeInsets.only(left: 5,right: 5),
                            child: GestureDetector(
                              onTap: (){
                                Get.to(SubSubjectScreen(Catname: subjectsData['category_name'],Catparentid:subjectsData['id'] ,));
                              },
                              child: Card(
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),
                                  side: BorderSide(color: textColor),),
                                child: Padding(
                                  padding:  EdgeInsets.only(left: 5,right: 10),
                                  child: Row(
                                    children: [
                                      Image.network( '${subjectsData['image']}',
                                        height: 50,
                                        width: 50,),
                                      sizebox_width_5,
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            width: size.width*.25,

                                            child: Text(
                                              '${subjectsData['category_name']}',
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.justify,
                                              style: TextStyle(
                                                  color: Color(0xFF6A6E70),
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                          sizebox_height_5,
                                          Container(
                                            width: size.width*.25,
                                            // color: Colors.red,
                                            child: Text(
                                              '${subjectsData['attempt_categories']}/${subjectsData['total_categories']} subcategory',
                                              textAlign: TextAlign.justify,
                                              style: TextStyle(
                                                  color: textColor,
                                                  fontSize: 11,
                                                  fontWeight: FontWeight.w400),
                                            ),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        }),
                  ],
                ),
              ),
            );
          }


        }
      ),
    );
  }
}
