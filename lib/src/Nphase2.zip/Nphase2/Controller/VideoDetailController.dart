import 'dart:convert';
import 'dart:developer';

import 'package:chewie/chewie.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:n_prep/Service/Service.dart';
import 'package:n_prep/constants/Api_Urls.dart';
import 'package:n_prep/src/Nphase2/Controller/netflixControlUi.dart';
import 'package:n_prep/utils/colors.dart';
// import 'package:simple_pip_mode/simple_pip.dart';
import 'package:video_player/video_player.dart';

class VideoDetailcontroller extends GetxController {
  var VideoDetailloader = false.obs;
  var VideoDetailCatid = 0.obs;
  var videoimage = "".obs;
  List VideoDetaildata = [];
  VideoPlayerController controller;
  ChewieController chewieController;
  Future<void> _initializeVideoPlayerFuture;
  updatecatid(id) {
    VideoDetailCatid.value = id;
    update();
  }

  videolisner() {
    chewieController.addListener((){
// if the controller is not fullscreen or exit fullscreen
// button is pressed, change the orientation
      if(chewieController.isFullScreen)
// This changes the oriention to potrait up
        SystemChrome.setPreferredOrientations(
            [DeviceOrientation.portraitUp]);

    });
  }
  void rewind() {
    controller.seekTo(
      Duration(seconds: controller.value.position.inSeconds - 10),
    );
    update();
  }



  void fastForward() {
    controller.seekTo(
      Duration(seconds: controller.value.position.inSeconds + 10),
    );
    update();
  }




  void toggleFullScreen() {
    chewieController.enterFullScreen();
  }

  String formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return '$twoDigitMinutes:$twoDigitSeconds';
  }
  @override
  void dispose() {
    Get.delete<VideoDetailcontroller>();
    controller.dispose();
    chewieController.dispose();
    super.dispose();
  }
  Widget _buildCustomControls() {
    return Column(
      children: [
        Expanded(
          child: Container(
            color: Colors.transparent,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                // Playback controls
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Icon(Icons.replay_10),
                      onPressed: rewind,
                    ),
                    IconButton(
                      icon: Icon(chewieController.isFullScreen
                          ? Icons.fullscreen_exit
                          : Icons.fullscreen),
                      onPressed: toggleFullScreen,
                    ),
                    IconButton(
                      icon: Icon(Icons.fast_forward),
                      onPressed: fastForward,
                    ),
                  ],
                ),
                SizedBox(height: 16),
                // Seek bar and video duration
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Text(
                        formatDuration(chewieController.videoPlayerController.value.position),
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                    Expanded(
                      child: VideoProgressIndicator(
                        chewieController.videoPlayerController,
                        allowScrubbing: true,
                        colors: VideoProgressColors(
                          playedColor: Colors.red,
                          // handleColor: Colors.red,
                          backgroundColor: Colors.grey,
                          bufferedColor: Colors.grey.withOpacity(0.5),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 8.0),
                      child: Text(
                        formatDuration(chewieController.videoPlayerController.value.duration),
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 16),
              ],
            ),
          ),
        ),
        SizedBox(height: 16),
      ],
    );
  }
  FetchVideoDetailData() async {
    VideoDetailloader(true);
    Map<String, String> queryParams = {
      "category_id": VideoDetailCatid.value.toString(),
    };
    String queryString = Uri(queryParameters: queryParams).query;
    var videourl_api = apiUrls().videos_deatil_api + '?' + queryString;
    log("FetchVideoDetailData url :${videourl_api} ");
    try {
      var result = await apiCallingHelper().getAPICall(videourl_api, true);
      // settingData =jsonDecode(result.body);

      if (result != null) {
        if (result.statusCode == 200) {
          var FetchSubjectData = jsonDecode(result.body);
          log("FetchVideoDetailData response :$FetchSubjectData ");
          VideoDetaildata.clear();
          VideoDetaildata.add(FetchSubjectData['data']);
          var videourl = VideoDetaildata[0]['video_attachment'];
          VideoDetailloader(false);
          videoimage.value = VideoDetaildata[0]['thumb_image'];

          controller = VideoPlayerController.networkUrl(
            Uri.parse(videourl),
            videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
          )..initialize().then((_) {
              // controller.play();
              // controller.setVolume(0.0);
            chewieController = ChewieController(
              videoPlayerController: controller,
showControls: true,
              aspectRatio: 16 / 9,
              autoInitialize: true,
              draggableProgressBar: true,
              allowPlaybackSpeedChanging: true, // Set to true to allow changing playback speed
              allowedScreenSleep: false, // Prevent the screen from sleeping during playback
              allowFullScreen: true,
              // customControls:  NetflixStyleControls(chewieController: chewieController,videoPlayerController: controller),
              // customControls:  _buildCustomControls(),


              cupertinoProgressColors: ChewieProgressColors(

                playedColor: primary,
                handleColor: drawerprimary,
                backgroundColor: lightPrimary,
                bufferedColor: hlightPrimary,
              ),
              // materialProgressColors: ChewieProgressColors(
              //   playedColor: primary,
              //   handleColor: drawerprimary,
              //   backgroundColor: lightPrimary,
              //   bufferedColor: hlightPrimary,
              // ),

            );
              update();
            });

          controller.setLooping(false);
          await controller.initialize();

          update();
          refresh();
        } else if (result.statusCode == 404) {
          VideoDetaildata = [];
          VideoDetailloader(false);
        } else {
          VideoDetaildata = [];
          VideoDetailloader(false);
        }
        update();
        refresh();
      }
    } catch (e) {
      log("FetchVideoDetailData error ........${e}");
      VideoDetailloader(false);
      update();
    }
  }
}
