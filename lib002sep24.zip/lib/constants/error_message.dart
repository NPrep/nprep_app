import 'package:logger/logger.dart';

Logger_D(message){
 return Logger().d("logger msg .... ${message}");
}
