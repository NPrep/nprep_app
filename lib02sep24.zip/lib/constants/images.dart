//
// String login_user




String anatomy = 'assets/images/sub_antomy.png';
String biochemistry = 'assets/images/sub_biochemistry.png';
String community = 'assets/images/sub_comm.png';
String forensic = 'assets/images/sub_forensic.png';
String microbiology = 'assets/images/sub_microblogy.png';
String pathology = 'assets/images/sub_pathology.png';
String pharmacology = 'assets/images/sub_pharma.png';
String physiology = 'assets/images/sub_physiolgy.png';
String medicine = 'assets/images/sub_medicine.png';

String subcategory = 'assets/images/epd_img1.png';
String subscription_plan = 'assets/images/plan_img.png';
String solve = 'assets/images/epd_solve.png';
String review_img = 'assets/images/review.png';
String background = 'assets/images/background.png';
String backgroundtop = 'assets/images/backgroundtop.jpg';
String backgroundfull = 'assets/images/backgrdfull.png';
String backfull = 'assets/images/fullimage.png';
String backgroundnew = "assets/images/backgroundnew.png";
String logo = 'assets/images/LOGO.png';

//Login page & Registration Page
String user_icon = 'assets/images/login_person.png';
String mobile_icon = 'assets/images/profile_phone.png';
String email_icon = 'assets/images/profile_email.png';
String password_icon = 'assets/images/login_password.png';
String country_icon = 'assets/images/country_reg.png';
String colege_icon = 'assets/images/college_reg.png';
String job_icon = 'assets/images/job_reg.png';
String google = 'assets/images/google_icon.png';

String home_group = 'assets/images/home_group.png';
String homeback_group = 'assets/images/homebackimage.png';
String home_poster = 'assets/images/home_poster.png';
String home_test = 'assets/images/home_category.png';
String home_test1 = 'assets/images/home_category1.png';
String home_previous = 'assets/images/home_previousq.png';

String contact_us = 'assets/images/img_contact.png';
String about_us = 'assets/images/img_about.png';

String profile_phone = 'assets/images/profile_phone.png';
String profile_email = 'assets/images/profile_email.png';
String profile_city = 'assets/images/city.png';
String profile_country = 'assets/images/profile_city.png';
String profile_state = 'assets/images/state.png';
String profile_user = 'assets/images/profile_user.png';

String d_home = 'assets/images/d_home.png';
String d_profile = 'assets/images/d_profile.png';
String d_payment = 'assets/images/d_payment.png';
String d_qbank = 'assets/images/d_qbank.png';
String d_test = 'assets/images/d_test.png';
String d_cpass = 'assets/images/d_cpass.png';
String d_privacy = 'assets/images/d_privacy.png';
String d_about = 'assets/images/d_about.png';
String d_contact = 'assets/images/d_contact.png';
String d_share = 'assets/images/d_share.png';
String d_logout = 'assets/images/d_logout.png';

String ques_poster = 'assets/images/ques_poster.png';