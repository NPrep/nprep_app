class RegController{
  callreg(body,url){

  }
  // var result =""
  //     if(result.statuscode==200){}
  //     else{}

}